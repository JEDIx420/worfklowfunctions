import { Client, Databases } from 'node-appwrite';
import { runWorkflow } from '../../../src/lib/workflow/engine';

export default async function main(req: any, res: any) {
  try {
    const { workflowId, initialInput } = req.body;
    if (!workflowId) {
      return res.json({ error: 'Missing workflowId' }, 400);
    }

    // Set up Appwrite client
    const client = new Client()
      .setEndpoint(process.env.APPWRITE_ENDPOINT!)
      .setProject(process.env.APPWRITE_PROJECT_ID!)
      .setKey(process.env.APPWRITE_API_KEY!);
    const databases = new Databases(client);

    // Fetch workflow definition from Appwrite DB
    const dbId = process.env.APPWRITE_DATABASE_ID!;
    const workflowsCol = process.env.APPWRITE_WORKFLOWS_COLLECTION_ID!;
    const workflowDoc = await databases.getDocument(dbId, workflowsCol, workflowId);
    const nodes = JSON.parse(workflowDoc.nodes);
    const edges = JSON.parse(workflowDoc.edges);

    // Run the workflow using your engine
    const result = await runWorkflow({ nodes, edges, initialInput });
    return res.json({ success: true, result });
  } catch (err: any) {
    return res.json({ error: err.message || 'Unknown error' }, 500);
  }
}
